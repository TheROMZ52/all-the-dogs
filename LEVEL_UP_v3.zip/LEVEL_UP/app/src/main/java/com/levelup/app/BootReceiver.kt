package com.levelup.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-creates all alarms after a restart or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.loadTasks(context).forEach { Scheduler.schedule(context, it) }
        val end = Store.focusEnd(context)
        if (end > System.currentTimeMillis()) Scheduler.scheduleFocus(context, end)
    }
}
