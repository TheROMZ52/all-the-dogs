package com.levelup.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class TaskItem(
    val id: Int, val title: String, val hour: Int, val minute: Int,
    val profile: String, val days: Int, val done: Boolean = false,
    val category: Int = 0, val note: String = "", val mathLock: Boolean = false
)

object Cats {
    val names = listOf("قدرت ذهن", "آمادگی جسمانی", "شخصیت", "هوش و تحصیلات", "مهارت و پول", "ظاهر و استایل", "قدرت عاطفی")
    val icons = listOf("🧠", "💪", "🎭", "📚", "💻", "🖤", "❤️")
    fun icon(i: Int) = icons.getOrElse(i) { "⭐" }
}

data class Template(val cat: Int, val title: String, val hour: Int, val minute: Int)

val TEMPLATES = listOf(
    Template(0, "مدیتیشن و تمرکز ۱۰ دقیقه‌ای", 7, 0),
    Template(0, "ژورنال‌نویسی و مرور تصمیم‌های امروز", 22, 0),
    Template(1, "تمرین بدنسازی", 17, 30),
    Template(1, "نوشیدن آب", 10, 0),
    Template(1, "رفتن به تخت (خواب ۷ تا ۸ ساعت)", 23, 0),
    Template(2, "مرور اهداف امروز؛ کمتر حرف، بیشتر عمل", 8, 30),
    Template(3, "مطالعه‌ی روزانه", 20, 0),
    Template(3, "یادگیری زبان انگلیسی", 19, 0),
    Template(3, "تمرین ریاضی و علوم", 18, 0),
    Template(4, "برنامه‌نویسی و ساخت پروژه", 16, 0),
    Template(4, "تولید محتوا", 15, 0),
    Template(4, "ثبت خرج‌ها و مدیریت پول", 21, 0),
    Template(5, "مراقبت از پوست و بهداشت", 8, 0),
    Template(6, "تماس با یک آدم قابل‌اعتماد", 19, 30)
)

val QUOTES = listOf(
    "هر روز کمی بهتر از دیروز.",
    "نظم از انگیزه قوی‌تره؛ امروز هم یه قدم بردار.",
    "کار کوچیکِ هر روز، از کار بزرگِ یه‌باره بیشتر می‌ارزه.",
    "حرف کمتر، عمل بیشتر.",
    "بدنت رو بساز، ذهنت رو تیز کن، آینده‌ات رو بنویس.",
    "امروز همون روزیه که یک سال بعد ازش ممنون می‌شی.",
    "استریکت رو نشکن؛ خودت رو ثابت کن.",
    "اعتمادبه‌نفس یعنی به خودت قول بدی و عمل کنی.",
    "شروع کن؛ کامل بودن لازم نیست."
)

data class Badge(val icon: String, val title: String, val desc: String, val unlocked: Boolean)

object Store {
    const val XP_TASK = 10
    const val XP_FOCUS = 30

    private fun p(c: Context) = c.getSharedPreferences("levelup", Context.MODE_PRIVATE)

    fun dayString(offset: Int = 0): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    // ---------- tasks ----------
    fun loadTasks(c: Context): List<TaskItem> {
        val arr = try { JSONArray(p(c).getString("tasks", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TaskItem(
                o.getInt("id"), o.getString("title"), o.getInt("hour"), o.getInt("minute"),
                o.getString("profile"), o.optInt("days", 127), o.optBoolean("done", false),
                o.optInt("category", 0), o.optString("note", ""), o.optBoolean("mathLock", false)
            )
        }
    }

    fun saveTasks(c: Context, list: List<TaskItem>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject().put("id", t.id).put("title", t.title).put("hour", t.hour)
                    .put("minute", t.minute).put("profile", t.profile).put("days", t.days)
                    .put("done", t.done).put("category", t.category).put("note", t.note)
                    .put("mathLock", t.mathLock)
            )
        }
        p(c).edit().putString("tasks", arr.toString()).apply()
    }

    fun task(c: Context, id: Int): TaskItem? = loadTasks(c).firstOrNull { it.id == id }

    fun nextId(c: Context): Int {
        val maxId = loadTasks(c).maxOfOrNull { it.id } ?: 0
        val n = maxOf(p(c).getInt("nextId", 1), maxId + 1)
        p(c).edit().putInt("nextId", n + 1).putInt("created", p(c).getInt("created", 0) + 1).apply()
        return n
    }

    // ---------- xp / level ----------
    fun getXp(c: Context) = p(c).getInt("xp", 0)
    fun catXp(c: Context, cat: Int) = p(c).getInt("cxp_$cat", 0)
    fun level(xp: Int) = xp / 100 + 1
    fun rank(level: Int) = when {
        level <= 2 -> "تازه‌کار"
        level <= 4 -> "جنگجو"
        level <= 7 -> "استاد"
        level <= 11 -> "قهرمان"
        else -> "افسانه"
    }

    fun addXp(c: Context, amount: Int, cat: Int) {
        val e = p(c).edit()
        e.putInt("xp", maxOf(0, getXp(c) + amount))
        e.putInt("cxp_$cat", maxOf(0, catXp(c, cat) + amount))
        e.apply()
    }

    // ---------- streak ----------
    fun getStreak(c: Context) = p(c).getInt("streak", 0)
    fun bestStreak(c: Context) = p(c).getInt("bestStreak", 0)

    fun markActive(c: Context) {
        val today = dayString()
        val last = p(c).getString("lastActive", "")
        if (last == today) return
        val s = if (last == dayString(-1)) getStreak(c) + 1 else 1
        p(c).edit().putInt("streak", s).putInt("bestStreak", maxOf(bestStreak(c), s))
            .putString("lastActive", today).apply()
    }

    fun resetIfNewDay(c: Context) {
        val today = dayString()
        if (p(c).getString("lastReset", "") == today) return
        saveTasks(c, loadTasks(c).map { it.copy(done = false) })
        val last = p(c).getString("lastActive", "")
        if (last != today && last != dayString(-1)) p(c).edit().putInt("streak", 0).apply()
        p(c).edit().putString("lastReset", today).apply()
    }

    // ---------- completing tasks ----------
    fun setDone(c: Context, id: Int, done: Boolean) {
        val list = loadTasks(c).toMutableList()
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = list[i]
        if (t.done == done) return
        list[i] = t.copy(done = done)
        saveTasks(c, list)
        val key = "stat_" + dayString()
        if (done) {
            addXp(c, XP_TASK, t.category); markActive(c)
            p(c).edit().putInt("totalDone", p(c).getInt("totalDone", 0) + 1)
                .putInt(key, p(c).getInt(key, 0) + 1).apply()
        } else {
            addXp(c, -XP_TASK, t.category)
            p(c).edit().putInt("totalDone", maxOf(0, p(c).getInt("totalDone", 0) - 1))
                .putInt(key, maxOf(0, p(c).getInt(key, 0) - 1)).apply()
        }
    }

    fun weekly(c: Context): List<Pair<String, Int>> {
        val names = arrayOf("یک", "دو", "سه", "چهار", "پنج", "جمعه", "شنبه")
        return (-6..0).map { off ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, off)
            names[cal.get(Calendar.DAY_OF_WEEK) - 1] to p(c).getInt("stat_" + dayString(off), 0)
        }
    }

    fun badges(c: Context): List<Badge> {
        val total = p(c).getInt("totalDone", 0)
        val best = bestStreak(c)
        val lvl = level(getXp(c))
        val focus = p(c).getInt("focusCount", 0)
        val created = p(c).getInt("created", 0)
        return listOf(
            Badge("🥇", "اولین قدم", "اولین کارت رو انجام بده", total >= 1),
            Badge("🔟", "ده‌تایی", "۱۰ کار انجام بده", total >= 10),
            Badge("💯", "صدتایی", "۱۰۰ کار انجام بده", total >= 100),
            Badge("🔥", "هفته‌ی آتشین", "۷ روز استریک", best >= 7),
            Badge("🌙", "ماه بی‌وقفه", "۳۰ روز استریک", best >= 30),
            Badge("👑", "لول ۵", "به لول ۵ برس", lvl >= 5),
            Badge("🎯", "فوکوس‌کار", "۵ جلسه‌ی تمرکز", focus >= 5),
            Badge("🗓️", "برنامه‌ریز", "۱۰ یادآور بساز", created >= 10)
        )
    }

    // ---------- focus timer ----------
    fun focusEnd(c: Context) = p(c).getLong("focusEnd", 0L)
    fun setFocusEnd(c: Context, v: Long) = p(c).edit().putLong("focusEnd", v).apply()
    fun finishFocus(c: Context) {
        if (focusEnd(c) == 0L) return
        addXp(c, XP_FOCUS, 0)
        p(c).edit().putInt("focusCount", p(c).getInt("focusCount", 0) + 1).putLong("focusEnd", 0L).apply()
    }

    // ---------- settings ----------
    fun ringtone(c: Context): String? = p(c).getString("ringtone", null)
    fun setRingtone(c: Context, v: String?) = p(c).edit().putString("ringtone", v).apply()
    fun vibrate(c: Context) = p(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = p(c).edit().putBoolean("vibrate", v).apply()
    fun gradual(c: Context) = p(c).getBoolean("gradual", true)
    fun setGradual(c: Context, v: Boolean) = p(c).edit().putBoolean("gradual", v).apply()
    fun forceMax(c: Context) = p(c).getBoolean("forceMax", false)
    fun setForceMax(c: Context, v: Boolean) = p(c).edit().putBoolean("forceMax", v).apply()
    fun snoozeMin(c: Context) = p(c).getInt("snoozeMin", 10)
    fun setSnoozeMin(c: Context, v: Int) = p(c).edit().putInt("snoozeMin", v).apply()
    fun profileActive(c: Context, profile: String) = p(c).getBoolean("profileOn_$profile", true)
    fun setProfileActive(c: Context, profile: String, v: Boolean) = p(c).edit().putBoolean("profileOn_$profile", v).apply()

    fun exportText(c: Context): String {
        val sb = StringBuilder("LEVEL UP 👑\nلول ${level(getXp(c))} | XP: ${getXp(c)} | استریک: ${getStreak(c)}\n\n")
        loadTasks(c).forEach { t ->
            sb.append("• %02d:%02d  %s %s (%s)\n".format(
                t.hour, t.minute, Cats.icon(t.category), t.title,
                if (t.profile == "school") "روز مدرسه" else "تعطیلات"
            ))
        }
        return sb.toString()
    }
}
