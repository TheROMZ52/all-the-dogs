package com.levelup.app

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full-screen alarm screen: shows over the lock screen and turns the display on. */
class AlarmActivity : ComponentActivity() {
    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { finish() }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(this, null)
        ContextCompat.registerReceiver(
            this, stopReceiver, IntentFilter(AlarmService.ACTION_STOPPED), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        val id = intent.getIntExtra("id", -1)
        val title = intent.getStringExtra("title") ?: ""
        val note = intent.getStringExtra("note") ?: ""
        val math = intent.getBooleanExtra("math", false)
        val cat = intent.getIntExtra("cat", 0)
        val kind = intent.getStringExtra("kind") ?: "task"
        setContent { LevelUpTheme { AlarmScreen(id, title, note, math, cat, kind) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    override fun onDestroy() {
        try { unregisterReceiver(stopReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun sendToService(action: String) {
        startService(Intent(this, AlarmService::class.java).setAction(action))
    }

    private fun complete(id: Int, kind: String) {
        when (kind) {
            "focus" -> Store.finishFocus(this)
            "test" -> { }
            else -> if (id >= 0) Store.setDone(this, id, true)
        }
        sendToService(AlarmService.ACTION_DISMISS)
        finish()
    }

    @Composable
    private fun AlarmScreen(id: Int, title: String, note: String, math: Boolean, cat: Int, kind: String) {
        val snoozeMin = remember { Store.snoozeMin(this@AlarmActivity) }
        var timeText by remember { mutableStateOf("") }
        LaunchedEffect(Unit) {
            while (true) {
                timeText = SimpleDateFormat("HH:mm", Locale.US).format(Date())
                delay(1000)
            }
        }
        var a by remember { mutableIntStateOf((6..15).random()) }
        var b by remember { mutableIntStateOf((3..9).random()) }
        var answer by remember { mutableStateOf("") }
        var wrong by remember { mutableStateOf(false) }

        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B0B0D)).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(timeText, fontSize = 72.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE5192B))
            Spacer(Modifier.height(12.dp))
            Text("${Cats.icon(cat)} $title", fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Color.White)
            if (note.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(note, fontSize = 16.sp, textAlign = TextAlign.Center, color = Color(0xFFCCCCCC))
            }
            Spacer(Modifier.height(28.dp))

            if (math) {
                Text("برای خاموش کردن، این مسئله رو حل کن:", color = Color(0xFFCCCCCC))
                Spacer(Modifier.height(8.dp))
                Text("$a × $b = ?", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it.filter(Char::isDigit).take(4); wrong = false },
                    singleLine = true,
                    isError = wrong,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    label = { Text(if (wrong) "اشتباه بود، یه مسئله‌ی جدید" else "جواب") }
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    if (answer.toIntOrNull() == a * b) complete(id, kind)
                    else { wrong = true; answer = ""; a = (6..15).random(); b = (3..9).random() }
                }, modifier = Modifier.fillMaxWidth()) { Text("تأیید و خاموش") }
            } else {
                Button(onClick = { complete(id, kind) }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Text(if (kind == "focus") "تمام شد 🎯" else "✅ انجام شد", fontSize = 18.sp)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { sendToService(AlarmService.ACTION_DISMISS); finish() }, modifier = Modifier.fillMaxWidth()) {
                    Text("خاموش")
                }
            }
            if (kind != "focus") {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { sendToService(AlarmService.ACTION_SNOOZE); finish() }, modifier = Modifier.fillMaxWidth()) {
                    Text("⏰ $snoozeMin دقیقه بعد")
                }
            }
        }
    }
}
