package com.levelup.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    const val SNOOZE_OFFSET = 500_000
    const val FOCUS_ID = 900_001

    fun nextTrigger(hour: Int, minute: Int, days: Int): Long {
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        while (c.timeInMillis <= now || (days and (1 shl (c.get(Calendar.DAY_OF_WEEK) - 1))) == 0) {
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }

    private fun alarmMgr(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun showIntent(c: Context) = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    // setAlarmClock = same mechanism as the phone's clock app: exact, works in Doze,
    // needs no special permission.
    private fun setClock(c: Context, code: Int, at: Long, kind: String, id: Int, title: String, note: String) {
        val intent = Intent(c, ReminderReceiver::class.java)
            .putExtra("kind", kind).putExtra("id", id).putExtra("title", title).putExtra("note", note)
        val pi = PendingIntent.getBroadcast(c, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarmMgr(c).setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(c)), pi)
    }

    private fun cancelCode(c: Context, code: Int) {
        val pi = PendingIntent.getBroadcast(
            c, code, Intent(c, ReminderReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) alarmMgr(c).cancel(pi)
    }

    fun schedule(c: Context, t: TaskItem) {
        setClock(c, t.id, nextTrigger(t.hour, t.minute, t.days), "task", t.id, t.title, t.note)
    }

    fun cancel(c: Context, t: TaskItem) {
        cancelCode(c, t.id)
        cancelCode(c, t.id + SNOOZE_OFFSET)
    }

    fun snooze(c: Context, id: Int, title: String, note: String, minutes: Int) {
        val at = System.currentTimeMillis() + minutes * 60_000L
        setClock(c, id + SNOOZE_OFFSET, at, "snooze", id, title, note)
    }

    fun scheduleFocus(c: Context, at: Long) = setClock(c, FOCUS_ID, at, "focus", FOCUS_ID, "پایان جلسه‌ی تمرکز", "")
    fun cancelFocus(c: Context) = cancelCode(c, FOCUS_ID)
}
