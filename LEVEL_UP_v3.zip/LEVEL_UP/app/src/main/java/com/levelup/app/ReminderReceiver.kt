package com.levelup.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.resetIfNewDay(context)
        val kind = intent.getStringExtra("kind") ?: "task"
        val id = intent.getIntExtra("id", -1)
        val extraTitle = intent.getStringExtra("title") ?: ""
        val extraNote = intent.getStringExtra("note") ?: ""
        when (kind) {
            "task" -> {
                val t = Store.task(context, id) ?: return
                Scheduler.schedule(context, t) // next occurrence first, so it never gets lost
                if (t.done || !Store.profileActive(context, t.profile)) return
                ring(context, t.id, t.title, t.note, t.mathLock, t.category, "task")
            }
            "snooze" -> {
                val t = Store.task(context, id)
                if (id >= 0 && (t == null || t.done)) return
                ring(context, id, t?.title ?: extraTitle, t?.note ?: extraNote, t?.mathLock ?: false, t?.category ?: 0, "snooze")
            }
            "focus" -> ring(context, Scheduler.FOCUS_ID, "پایان جلسه‌ی تمرکز 🎯", "عالی بود! یه استراحت کوتاه بکن.", false, 0, "focus")
        }
    }

    companion object {
        fun ring(c: Context, id: Int, title: String, note: String, math: Boolean, cat: Int, kind: String) {
            val i = Intent(c, AlarmService::class.java)
                .putExtra("id", id).putExtra("title", title).putExtra("note", note)
                .putExtra("math", math).putExtra("cat", cat).putExtra("kind", kind)
            try { ContextCompat.startForegroundService(c, i) } catch (e: Exception) { }
        }
    }
}
