package com.levelup.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Rings like a real alarm clock: looping alarm-stream sound + vibration until dismissed. */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var volume = 1f

    private var curId = -1
    private var curTitle = ""
    private var curNote = ""
    private var curMath = false
    private var curCat = 0
    private var curKind = "task"

    private val rampRunnable = object : Runnable {
        override fun run() {
            volume = minOf(1f, volume + 0.05f)
            player?.setVolume(volume, volume)
            if (volume < 1f) handler.postDelayed(this, 1500)
        }
    }
    private val timeoutRunnable = Runnable { stopAll() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISMISS -> { stopAll(); return START_NOT_STICKY }
            ACTION_SNOOZE -> { snoozeCurrent(); stopAll(); return START_NOT_STICKY }
        }
        if (intent == null) { stopSelf(); return START_NOT_STICKY }

        curId = intent.getIntExtra("id", -1)
        curTitle = intent.getStringExtra("title") ?: ""
        curNote = intent.getStringExtra("note") ?: ""
        curMath = intent.getBooleanExtra("math", false)
        curCat = intent.getIntExtra("cat", 0)
        curKind = intent.getStringExtra("kind") ?: "task"

        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
        cleanup()
        acquireWake()
        startSound()
        startVibration()
        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, 10 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun snoozeCurrent() {
        if (curKind == "focus") return
        Scheduler.snooze(this, curId, curTitle, curNote, Store.snoozeMin(this))
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "زنگ هشدار LEVEL UP", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(ch)

        val act = Intent(this, AlarmActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("id", curId); putExtra("title", curTitle); putExtra("note", curNote)
            putExtra("math", curMath); putExtra("cat", curCat); putExtra("kind", curKind)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val full = PendingIntent.getActivity(this, 1, act, flags)
        val snoozePi = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags)
        val dismissPi = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_DISMISS), flags)

        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ $curTitle")
            .setContentText(if (curNote.isNotBlank()) curNote else "وقت انجام برنامه است")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .addAction(0, "⏰ ${Store.snoozeMin(this)} دقیقه بعد", snoozePi)
        if (!curMath) b.addAction(0, "خاموش", dismissPi)
        return b.build()
    }

    private fun acquireWake() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "levelup:alarm").apply { acquire(10 * 60 * 1000L) }
    }

    private fun startSound() {
        if (Store.forceMax(this)) {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        }
        val uri: Uri = Store.ringtone(this)?.let { Uri.parse(it) }
            ?: RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        fun make(u: Uri): MediaPlayer = MediaPlayer().apply {
            setAudioAttributes(attrs)
            setDataSource(this@AlarmService, u)
            isLooping = true
            prepare()
        }

        val mp: MediaPlayer = try { make(uri) } catch (e: Exception) {
            try { make(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)) } catch (e2: Exception) { return }
        }
        player = mp
        volume = if (Store.gradual(this)) 0.15f else 1f
        mp.setVolume(volume, volume)
        mp.start()
        if (Store.gradual(this)) handler.postDelayed(rampRunnable, 1500)
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        if (!Store.vibrate(this)) return
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        val effect = VibrationEffect.createWaveform(longArrayOf(0, 900, 600, 900, 600), 0)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        v.vibrate(effect, attrs)
    }

    private fun cleanup() {
        handler.removeCallbacks(rampRunnable)
        try { player?.stop() } catch (e: Exception) { }
        player?.release(); player = null
        vibrator?.cancel(); vibrator = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun stopAll() {
        handler.removeCallbacksAndMessages(null)
        cleanup()
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "level_up_ring_v3"
        const val NOTIF_ID = 4242
        const val ACTION_DISMISS = "com.levelup.app.DISMISS"
        const val ACTION_SNOOZE = "com.levelup.app.SNOOZE"
        const val ACTION_STOPPED = "com.levelup.app.ALARM_STOPPED"
    }
}
