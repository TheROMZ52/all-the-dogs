package com.levelup.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val LevelColors = darkColorScheme(
    primary = Color(0xFFE5192B), onPrimary = Color.White,
    background = Color(0xFF0B0B0D), onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF16161A), onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1E1E24), onSurfaceVariant = Color(0xFFCCCCCC)
)

@Composable
fun LevelUpTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = LevelColors, content = content)
    }
}
