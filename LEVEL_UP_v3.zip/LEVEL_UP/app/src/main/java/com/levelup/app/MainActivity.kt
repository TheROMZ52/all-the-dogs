package com.levelup.app

import android.app.NotificationManager
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Calendar

private val DAY_LIST = listOf("ش" to 6, "ی" to 0, "د" to 1, "س" to 2, "چ" to 3, "پ" to 4, "ج" to 5)

class MainActivity : ComponentActivity() {
    private val tasks = mutableStateListOf<TaskItem>()
    private var xp by mutableIntStateOf(0)
    private var streak by mutableIntStateOf(0)
    private var focusEnd by mutableLongStateOf(0L)
    private var ringtoneName by mutableStateOf("پیش‌فرض گوشی")
    private var schoolOn by mutableStateOf(true)
    private var holidayOn by mutableStateOf(true)
    private var refreshKey by mutableIntStateOf(0)

    private val ringtoneLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            @Suppress("DEPRECATION")
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33)
                r.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            else r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            Store.setRingtone(this, uri?.toString())
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        askFullScreenOnce()
        Store.loadTasks(this).forEach { Scheduler.schedule(this, it) }
        setContent { LevelUpTheme { LevelUpScreen() } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun askFullScreenOnce() {
        if (Build.VERSION.SDK_INT < 34) return
        val prefs = getSharedPreferences("levelup", MODE_PRIVATE)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.canUseFullScreenIntent() && !prefs.getBoolean("askedFullScreen", false)) {
            prefs.edit().putBoolean("askedFullScreen", true).apply()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }
    }

    private fun refresh() {
        Store.resetIfNewDay(this)
        tasks.clear(); tasks.addAll(Store.loadTasks(this))
        xp = Store.getXp(this); streak = Store.getStreak(this)
        val end = Store.focusEnd(this)
        if (end > 0L && System.currentTimeMillis() - end > 15 * 60_000L) { Store.setFocusEnd(this, 0L); focusEnd = 0L }
        else focusEnd = end
        schoolOn = Store.profileActive(this, "school")
        holidayOn = Store.profileActive(this, "holiday")
        ringtoneName = Store.ringtone(this)?.let {
            try { RingtoneManager.getRingtone(this, Uri.parse(it)).getTitle(this) } catch (e: Exception) { "انتخاب‌شده" }
        } ?: "پیش‌فرض گوشی"
        refreshKey++
    }

    private fun toggleDone(task: TaskItem, checked: Boolean) {
        Store.setDone(this, task.id, checked)
        refresh()
    }

    private fun upsert(task: TaskItem) {
        val t = if (task.id == 0) task.copy(id = Store.nextId(this)) else task
        val list = Store.loadTasks(this).toMutableList()
        val i = list.indexOfFirst { it.id == t.id }
        if (i >= 0) list[i] = t else list.add(t)
        Store.saveTasks(this, list)
        Scheduler.schedule(this, t)
        refresh()
    }

    private fun remove(task: TaskItem) {
        Scheduler.cancel(this, task)
        Store.saveTasks(this, Store.loadTasks(this).filter { it.id != task.id })
        refresh()
    }

    private fun startFocus(minutes: Int) {
        val end = System.currentTimeMillis() + minutes * 60_000L
        Store.setFocusEnd(this, end)
        Scheduler.scheduleFocus(this, end)
        focusEnd = end
    }

    private fun cancelFocus() {
        Scheduler.cancelFocus(this)
        Store.setFocusEnd(this, 0L)
        focusEnd = 0L
    }

    private fun testRing() {
        ReminderReceiver.ring(this, -2, "تست زنگ هشدار ⏰", "اگه این صفحه و صدا رو دیدی، همه‌چی درسته", false, 0, "test")
        startActivity(
            Intent(this, AlarmActivity::class.java)
                .putExtra("id", -2).putExtra("title", "تست زنگ هشدار ⏰")
                .putExtra("note", "اگه این صفحه و صدا رو دیدی، همه‌چی درسته")
                .putExtra("math", false).putExtra("cat", 0).putExtra("kind", "test")
        )
    }

    private fun pickRingtone() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "آهنگ زنگ")
        Store.ringtone(this)?.let { i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
        ringtoneLauncher.launch(i)
    }

    private fun exportTasks() {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Store.exportText(this))
        startActivity(Intent.createChooser(send, "خروجی گرفتن"))
    }

    private fun isActive(profile: String) = if (profile == "school") schoolOn else holidayOn

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun LevelUpScreen() {
        val ctx = this@MainActivity
        var profile by remember { mutableStateOf("school") }
        var dialog by remember { mutableStateOf<String?>(null) }
        var editing by remember { mutableStateOf<TaskItem?>(null) }
        var showStats by remember { mutableStateOf(false) }
        var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) { nowMs = System.currentTimeMillis(); delay(1000) }
        }
        val visible = tasks.filter { it.profile == profile }
        val quote = remember { QUOTES[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % QUOTES.size] }
        val cardColors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("LEVEL UP 👑") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                    actions = {
                        TextButton(onClick = { showStats = !showStats }) { Text("آمار") }
                        TextButton(onClick = { dialog = "settings" }) { Text("⚙️ تنظیمات") }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { editing = null; dialog = "task" }) { Icon(Icons.Default.Add, "افزودن") }
            }
        ) { padding ->
            LazyColumn(
                Modifier.padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // ---- level card ----
                item {
                    val level = Store.level(xp)
                    val best = remember(refreshKey) { Store.bestStreak(ctx) }
                    Card(colors = cardColors) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("👑 ${Store.rank(level)}  •  لول $level", style = MaterialTheme.typography.titleLarge)
                            LinearProgressIndicator(progress = { (xp % 100) / 100f }, modifier = Modifier.fillMaxWidth())
                            Text("${xp % 100}/100 XP تا لول بعدی   •   🔥 استریک: $streak روز (رکورد: $best)")
                            Text(quote, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                // ---- next alarm ----
                item {
                    val next = tasks.filter { isActive(it.profile) }
                        .map { it to Scheduler.nextTrigger(it.hour, it.minute, it.days) }
                        .minByOrNull { it.second }
                    val text = if (next == null) "⏰ هیچ زنگ فعالی نداری"
                    else {
                        val mins = ((next.second - nowMs) / 60_000L).coerceAtLeast(0)
                        val left = if (mins >= 60) "${mins / 60} ساعت و ${mins % 60} دقیقه" else "$mins دقیقه"
                        "⏰ زنگ بعدی: «${next.first.title}» ساعت %02d:%02d  (%s دیگه)".format(next.first.hour, next.first.minute, left)
                    }
                    Text(text, style = MaterialTheme.typography.bodyMedium)
                }
                // ---- focus ----
                item {
                    Card(colors = cardColors) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🎯 حالت تمرکز (+${Store.XP_FOCUS} XP)", style = MaterialTheme.typography.titleMedium)
                            if (focusEnd > 0L) {
                                val remaining = focusEnd - nowMs
                                if (remaining > 0) {
                                    Text(String.format("%02d:%02d", remaining / 60000, (remaining / 1000) % 60), style = MaterialTheme.typography.headlineMedium)
                                    OutlinedButton(onClick = { cancelFocus() }) { Text("لغو") }
                                } else {
                                    Text("زمان تمام شد! زنگ رو خاموش کن تا امتیازت ثبت بشه ✅")
                                }
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(15, 25, 45).forEach { m -> Button(onClick = { startFocus(m) }) { Text("$m دقیقه") } }
                                }
                            }
                        }
                    }
                }
                // ---- stats ----
                if (showStats) {
                    item {
                        val weekly = remember(refreshKey) { Store.weekly(ctx) }
                        val badges = remember(refreshKey) { Store.badges(ctx) }
                        val catXp = remember(refreshKey) { Cats.names.indices.map { Store.catXp(ctx, it) } }
                        Card(colors = cardColors) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("📊 این هفته", style = MaterialTheme.typography.titleMedium)
                                val maxV = maxOf(1, weekly.maxOf { it.second })
                                Row(Modifier.fillMaxWidth().height(120.dp), verticalAlignment = Alignment.Bottom) {
                                    weekly.forEach { (label, n) ->
                                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("$n")
                                            Box(
                                                Modifier.width(18.dp).height((4 + 70 * n / maxV).dp)
                                                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                                            )
                                            Text(label, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                                Text("🧭 پیشرفت هر بخش", style = MaterialTheme.typography.titleMedium)
                                val maxC = maxOf(100, catXp.max())
                                Cats.names.forEachIndexed { i, n ->
                                    Text("${Cats.icon(i)} $n — ${catXp[i]} XP", style = MaterialTheme.typography.bodySmall)
                                    LinearProgressIndicator(progress = { catXp[i] / maxC.toFloat() }, modifier = Modifier.fillMaxWidth())
                                }
                                Text("🏅 دستاوردها", style = MaterialTheme.typography.titleMedium)
                                badges.forEach { b ->
                                    Text(
                                        (if (b.unlocked) "${b.icon} ${b.title} — ${b.desc} ✅" else "🔒 ${b.title} — ${b.desc}"),
                                        color = if (b.unlocked) MaterialTheme.colorScheme.onSurface else Color(0xFF888888)
                                    )
                                }
                                Text("کل XP: $xp   |   کارهای ثبت‌شده: ${tasks.size}   |   انجام‌شده امروز: ${tasks.count { it.done }}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                // ---- profile ----
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = profile == "school", onClick = { profile = "school" }, label = { Text("روز مدرسه") })
                            FilterChip(selected = profile == "holiday", onClick = { profile = "holiday" }, label = { Text("تعطیلات") })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isActive(profile)) "زنگ‌ها فعال" else "زنگ‌ها خاموش", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.width(6.dp))
                            Switch(checked = isActive(profile), onCheckedChange = {
                                Store.setProfileActive(ctx, profile, it); refresh()
                            })
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { dialog = "templates" }, modifier = Modifier.fillMaxWidth()) {
                        Text("🗺️ افزودن سریع از نقشه‌ی رشد")
                    }
                }
                if (visible.isEmpty()) {
                    item { Text("هنوز کاری ثبت نکردی. با دکمه + یا نقشه‌ی رشد اولین یادآور را بساز.") }
                }
                items(visible, key = { it.id }) { task ->
                    Card(colors = cardColors) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${Cats.icon(task.category)} ${task.title}", style = MaterialTheme.typography.titleMedium)
                                Text("%02d:%02d".format(task.hour, task.minute) + (if (task.mathLock) "  •  🔒 قفل ریاضی" else ""))
                                if (task.note.isNotBlank()) Text(task.note, style = MaterialTheme.typography.bodySmall)
                            }
                            Checkbox(checked = task.done, onCheckedChange = { toggleDone(task, it) })
                            IconButton(onClick = { editing = task; dialog = "task" }) { Icon(Icons.Default.Edit, "ویرایش") }
                            IconButton(onClick = { remove(task) }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }

        when (dialog) {
            "task" -> TaskDialog(editing, profile, onDismiss = { dialog = null }, onSave = { upsert(it); dialog = null })
            "templates" -> TemplatesDialog(
                onDismiss = { dialog = null },
                onPick = { tp ->
                    upsert(TaskItem(0, tp.title, tp.hour, tp.minute, profile, 127, false, tp.cat))
                }
            )
            "settings" -> SettingsDialog(onDismiss = { dialog = null })
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun TaskDialog(editing: TaskItem?, profile: String, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
        var title by remember { mutableStateOf(editing?.title ?: "") }
        var hour by remember { mutableStateOf("%02d".format(editing?.hour ?: 18)) }
        var minute by remember { mutableStateOf("%02d".format(editing?.minute ?: 0)) }
        var days by remember { mutableIntStateOf(editing?.days ?: 127) }
        var cat by remember { mutableIntStateOf(editing?.category ?: 0) }
        var note by remember { mutableStateOf(editing?.note ?: "") }
        var math by remember { mutableStateOf(editing?.mathLock ?: false) }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(if (editing == null) "یادآور جدید" else "ویرایش یادآور") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("عنوان کار") }, singleLine = true)
                    OutlinedTextField(note, { note = it }, label = { Text("یادداشت (اختیاری)") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, label = { Text("ساعت") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, label = { Text("دقیقه") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    }
                    Text("روزهای تکرار:")
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        DAY_LIST.forEach { (label, bit) ->
                            FilterChip(selected = (days and (1 shl bit)) != 0, onClick = { days = days xor (1 shl bit) }, label = { Text(label) })
                        }
                    }
                    Text("دسته:")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Cats.names.forEachIndexed { i, n ->
                            FilterChip(selected = cat == i, onClick = { cat = i }, label = { Text("${Cats.icon(i)} $n") })
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("🔒 قفل ریاضی برای خاموش کردن زنگ")
                        Switch(checked = math, onCheckedChange = { math = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val h = hour.toIntOrNull(); val m = minute.toIntOrNull()
                    if (title.isNotBlank() && h != null && m != null && h in 0..23 && m in 0..59 && days != 0) {
                        onSave(
                            TaskItem(
                                id = editing?.id ?: 0, title = title.trim(), hour = h, minute = m,
                                profile = editing?.profile ?: profile, days = days, done = editing?.done ?: false,
                                category = cat, note = note.trim(), mathLock = math
                            )
                        )
                    }
                }) { Text("ذخیره و فعال‌سازی") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("لغو") } }
        )
    }

    @Composable
    private fun TemplatesDialog(onDismiss: () -> Unit, onPick: (Template) -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("🗺️ از نقشه‌ی رشد") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("روی هر مورد بزن تا با همه‌ی روزها به پروفایل فعلی اضافه بشه:", style = MaterialTheme.typography.bodySmall)
                    TEMPLATES.forEach { tp ->
                        TextButton(onClick = { onPick(tp) }, modifier = Modifier.fillMaxWidth()) {
                            Text("${Cats.icon(tp.cat)} ${tp.title}  (%02d:%02d)".format(tp.hour, tp.minute))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("تمام") } }
        )
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun SettingsDialog(onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        var vib by remember { mutableStateOf(Store.vibrate(ctx)) }
        var gradual by remember { mutableStateOf(Store.gradual(ctx)) }
        var max by remember { mutableStateOf(Store.forceMax(ctx)) }
        var snooze by remember { mutableIntStateOf(Store.snoozeMin(ctx)) }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("⚙️ تنظیمات زنگ") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("آهنگ زنگ: $ringtoneName")
                    OutlinedButton(onClick = { pickRingtone() }, modifier = Modifier.fillMaxWidth()) { Text("🎵 انتخاب آهنگ زنگ") }
                    SwitchRow("📳 ویبره", vib) { vib = it; Store.setVibrate(ctx, it) }
                    SwitchRow("🔊 افزایش تدریجی صدا", gradual) { gradual = it; Store.setGradual(ctx, it) }
                    SwitchRow("📢 بلندترین صدا موقع زنگ", max) { max = it; Store.setForceMax(ctx, it) }
                    Text("زمان چرت (اسنوز):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(5, 10, 15, 20).forEach { m ->
                            FilterChip(selected = snooze == m, onClick = { snooze = m; Store.setSnoozeMin(ctx, m) }, label = { Text("$m") })
                        }
                    }
                    Button(onClick = { testRing() }, modifier = Modifier.fillMaxWidth()) { Text("⏰ تست زنگ هشدار") }
                    OutlinedButton(onClick = { exportTasks() }, modifier = Modifier.fillMaxWidth()) { Text("📤 خروجی گرفتن از کارها") }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("تمام") } }
        )
    }

    @Composable
    private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
